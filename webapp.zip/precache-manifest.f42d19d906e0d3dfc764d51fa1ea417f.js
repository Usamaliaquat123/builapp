self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5aebe037e851ca125f9eee7dc4ed4861",
    "url": "/reactapp/index.html"
  },
  {
    "revision": "38c42db72c811f9db9a1",
    "url": "/reactapp/static/css/main.6b3658f3.chunk.css"
  },
  {
    "revision": "0b06208af285416ce766",
    "url": "/reactapp/static/js/2.1930d4f1.chunk.js"
  },
  {
    "revision": "38c42db72c811f9db9a1",
    "url": "/reactapp/static/js/main.97f88de5.chunk.js"
  },
  {
    "revision": "1380d1e067ed6cc9798c",
    "url": "/reactapp/static/js/runtime~main.ad8ebcea.js"
  },
  {
    "revision": "8bec95a3feea14b021355c29bf886fa3",
    "url": "/reactapp/static/media/01.8bec95a3.png"
  },
  {
    "revision": "bab6fa7e0deb4dc85b689d3ee1013d84",
    "url": "/reactapp/static/media/02.bab6fa7e.png"
  },
  {
    "revision": "7742e0cf8f2c40811a4697dc09c78cf7",
    "url": "/reactapp/static/media/03.7742e0cf.png"
  },
  {
    "revision": "6970857d01bfa898a3ffa4adf4d54684",
    "url": "/reactapp/static/media/04.6970857d.png"
  },
  {
    "revision": "6b7da70240975c12830861e54bc117bd",
    "url": "/reactapp/static/media/05.6b7da702.png"
  },
  {
    "revision": "e25bddbf887b68063da4fd4ec9bcb4b6",
    "url": "/reactapp/static/media/06.e25bddbf.png"
  },
  {
    "revision": "13857b6f11e9c5ad7e6863ac50b31125",
    "url": "/reactapp/static/media/1.13857b6f.png"
  },
  {
    "revision": "ebf5b869ea9b886c694872878b0fe81b",
    "url": "/reactapp/static/media/1.ebf5b869.png"
  },
  {
    "revision": "d6824001d05b11c1a14a6c131d6558b4",
    "url": "/reactapp/static/media/HomeSlide1.d6824001.jpg"
  },
  {
    "revision": "1233fdf19c04333c7f58af4eb8698452",
    "url": "/reactapp/static/media/Lato-Black.1233fdf1.ttf"
  },
  {
    "revision": "eb9532033c2adf99b1314611b5e9cd0e",
    "url": "/reactapp/static/media/Lato-Bold.eb953203.ttf"
  },
  {
    "revision": "01577cc25f44d5cd3451a5e0da715917",
    "url": "/reactapp/static/media/Lato-BoldItalic.01577cc2.ttf"
  },
  {
    "revision": "093466c99afdd5e38cfe3062dbcbba6b",
    "url": "/reactapp/static/media/Lato-Heavy.093466c9.ttf"
  },
  {
    "revision": "90e1d3559ac52f7f0f77a86e1bfd632d",
    "url": "/reactapp/static/media/Lato-Light.90e1d355.ttf"
  },
  {
    "revision": "863b7dcd5ec2c3923122af25ce0f7e4c",
    "url": "/reactapp/static/media/Lato-Medium.863b7dcd.ttf"
  },
  {
    "revision": "3b9b99039cc0a98dd50c3cbfac57ccb2",
    "url": "/reactapp/static/media/Lato-Regular.3b9b9903.ttf"
  },
  {
    "revision": "eb1635403cd764912ca1e0af78735797",
    "url": "/reactapp/static/media/Lato-Thin.eb163540.ttf"
  },
  {
    "revision": "a3b387c93882604792867736aecd56c8",
    "url": "/reactapp/static/media/Montserrat-Bold.a3b387c9.ttf"
  },
  {
    "revision": "0098f804fc2d06af52650e0b8ed3390c",
    "url": "/reactapp/static/media/Montserrat-Medium.0098f804.ttf"
  },
  {
    "revision": "505f8bf0da6de0bcc0e03a678ea7f054",
    "url": "/reactapp/static/media/bachi.505f8bf0.png"
  },
  {
    "revision": "e6ed5139f169d1b8c298fe62d8f39236",
    "url": "/reactapp/static/media/bachi.e6ed5139.png"
  },
  {
    "revision": "7ff12037ae31d86c6e985137b9529e65",
    "url": "/reactapp/static/media/bachiBachaRun.7ff12037.png"
  },
  {
    "revision": "c3f5cfa926438eb1ef1fefdde0d2d3fd",
    "url": "/reactapp/static/media/bachiWatching.c3f5cfa9.png"
  },
  {
    "revision": "983777349b66195c2921407680b80a89",
    "url": "/reactapp/static/media/backgroud_of_bachi.98377734.png"
  },
  {
    "revision": "7da27637f547c7ff7fd8e252db082f92",
    "url": "/reactapp/static/media/bvpc.7da27637.png"
  },
  {
    "revision": "b49acffa5009f503011f8ecc2864240f",
    "url": "/reactapp/static/media/bvpc2.b49acffa.png"
  },
  {
    "revision": "33025407eb9987d39373d004b3785572",
    "url": "/reactapp/static/media/donateAid.33025407.jpg"
  },
  {
    "revision": "a6bf80c10056ef70a65017dc1ef83c66",
    "url": "/reactapp/static/media/donation.a6bf80c1.png"
  },
  {
    "revision": "b229e9cfc91e62234594d5da64a4f44e",
    "url": "/reactapp/static/media/eductionLesson.b229e9cf.png"
  },
  {
    "revision": "2daab78878f67d27cc685a8b40b7c6d4",
    "url": "/reactapp/static/media/getInv.2daab788.png"
  },
  {
    "revision": "fafb88a85446962294622a568c4c88f4",
    "url": "/reactapp/static/media/ghar.fafb88a8.png"
  },
  {
    "revision": "c6059c4d553d435318fbe4c70ee0cd52",
    "url": "/reactapp/static/media/homeLesson.c6059c4d.png"
  },
  {
    "revision": "38398991fe18cfde6927427d4c5f3fbb",
    "url": "/reactapp/static/media/jact.38398991.png"
  },
  {
    "revision": "13d2828c26c6d9e4f6fe88d80ae55e63",
    "url": "/reactapp/static/media/jact2.13d2828c.png"
  },
  {
    "revision": "2435f2a1a6570abc6cf8a3a509d49706",
    "url": "/reactapp/static/media/logo.2435f2a1.png"
  },
  {
    "revision": "ee7cd8ed2dcec943251eb2763684fc6f",
    "url": "/reactapp/static/media/logo.ee7cd8ed.svg"
  },
  {
    "revision": "9e08e9095fc2408d391fc181f7e3be0d",
    "url": "/reactapp/static/media/logoUpdate.9e08e909.png"
  },
  {
    "revision": "3d865adace8736dd5fbfce1540da5744",
    "url": "/reactapp/static/media/paymentSucess.3d865ada.png"
  },
  {
    "revision": "bfa9e54d96026a231bb192185f8e4abe",
    "url": "/reactapp/static/media/postImg.bfa9e54d.png"
  },
  {
    "revision": "77f8f55065c573fd71dd02dc5a76a1bd",
    "url": "/reactapp/static/media/slide2.77f8f550.png"
  },
  {
    "revision": "35f9e3a9da4777b22f8f07d4e9454fd6",
    "url": "/reactapp/static/media/svpc.35f9e3a9.png"
  },
  {
    "revision": "46de7820fcdd3ac89eab9b162d433c6b",
    "url": "/reactapp/static/media/svpc2.46de7820.png"
  },
  {
    "revision": "dccefd745974626698d2f63746767ef6",
    "url": "/reactapp/static/media/tafreeTeacher.dccefd74.png"
  },
  {
    "revision": "647d539c845cbcc419668567784d2ad5",
    "url": "/reactapp/static/media/teacher.647d539c.png"
  },
  {
    "revision": "f00ba5d09cb1279903cfa6dfcf8248cd",
    "url": "/reactapp/static/media/teachers_background.f00ba5d0.png"
  },
  {
    "revision": "976b2824cb67a30303f596a09ffd7062",
    "url": "/reactapp/static/media/tharki_medal.976b2824.png"
  },
  {
    "revision": "be1999cff65cb436490eed4f1adc2573",
    "url": "/reactapp/static/media/tharki_teacher.be1999cf.png"
  }
]);